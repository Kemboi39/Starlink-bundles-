import React, { useState } from 'react';
import { DataPackage, Purchase } from './types';
import { DATA_PACKAGES, packageLabel, formatUGX } from './data/packages';
import { CheckoutSheet } from './components/CheckoutSheet';

export default function App() {
  const [selected, setSelected] = useState<DataPackage | null>(null);
  const [sheetOpen, setSheetOpen] = useState(false);

  const openPay = (pkg: DataPackage) => {
    setSelected(pkg);
    setSheetOpen(true);
  };

  const handleSuccess = (_purchase: Purchase) => {
    // Payment succeeded & bundle marked activated via CheckoutSheet
  };

  return (
    <div className="min-h-dvh flex flex-col bg-[var(--bg)] text-[var(--text)]">
      {/* Sticky top bar */}
      <header className="sticky top-0 z-40 bg-[var(--ink)] text-white pt-[env(safe-area-inset-top)] shadow-[0_1px_0_#ffffff14]">
        <div className="w-full max-w-[880px] mx-auto px-4">
          <div className="flex items-center justify-between h-14">
            <div className="flex items-center gap-2">
              <svg width="26" height="26" viewBox="0 0 32 32" aria-hidden="true">
                <defs>
                  <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
                    <stop stopColor="#7CF0AE" />
                    <stop offset="1" stopColor="#19C45A" />
                  </linearGradient>
                </defs>
                <path
                  d="M16 2c1 7 4 12 14 14-10 2-13 7-14 14-1-7-4-12-14-14C12 14 15 9 16 2z"
                  fill="url(#g)"
                />
                <circle cx="25.5" cy="6.5" r="2" fill="#fff" />
              </svg>
              <b className="text-lg font-bold tracking-tight">
                Star<span className="text-[var(--gold)]">Link</span>
              </b>
            </div>
            <div className="flex gap-2" aria-label="Supported networks">
              <span className="font-semibold text-xs leading-none px-2.5 py-2 rounded-full bg-[#FFCC00] text-[#111]">
                MTN
              </span>
              <span className="font-semibold text-xs leading-none px-2.5 py-2 rounded-full bg-[#E8202A] text-white">
                Airtel
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero band */}
      <div className="bg-gradient-to-br from-[#0C5A3E] to-[#093626] text-white relative overflow-hidden">
        <div
          className="absolute inset-0 pointer-events-none"
          style={{
            background:
              'radial-gradient(1.5px 1.5px at 14% 35%,#fff9,transparent),radial-gradient(1px 1px at 52% 22%,#fff8,transparent),radial-gradient(1.5px 1.5px at 84% 60%,#fffa,transparent),radial-gradient(1px 1px at 70% 85%,#fff6,transparent),radial-gradient(460px 240px at 92% -20%,#19C45A66,transparent 70%)',
          }}
        />
        <div className="w-full max-w-[880px] mx-auto px-4 relative">
          <section className="py-6 sm:pb-8">
            <span className="inline-flex items-center gap-1.5 bg-[#19C45A26] border border-[#5EEA9A66] text-[#B8F7D1] font-semibold text-xs px-3 py-2 rounded-full mb-3">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--gold)" strokeWidth="2">
                <path d="M9 3l3 3-3 3-3-3zM15 9l3 3-3 3-3-3z" />
                <path d="M10.5 10.5l3 3M4 14a6 6 0 006 6M4 10a10 10 0 0010 10" />
              </svg>
              Direct-to-cell bundles
            </span>
            <h1 className="text-[clamp(22px,4.6vw,28px)] font-bold leading-tight">
              Data that goes wherever you do.
            </h1>
            <p className="text-[#C4C8E8] mt-2 max-w-[48ch]">
              Pick a bundle, complete the purchase, and it's active in seconds.
            </p>
            <div className="flex flex-wrap gap-x-4 gap-y-2 mt-3 text-[13px] text-[#E3E5F8]">
              <span className="flex items-center gap-1.5">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--gold)" strokeWidth="2.4">
                  <path d="M13 3L4 14h7l-1 7 9-11h-7z" />
                </svg>
                Instant activation
              </span>
              <span className="flex items-center gap-1.5">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--gold)" strokeWidth="2.4">
                  <path d="M5 12.5l4.5 4.5L19 7.5" />
                </svg>
                Works on MTN and Airtel
              </span>
              <span className="flex items-center gap-1.5">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--gold)" strokeWidth="2">
                  <path d="M9 3l3 3-3 3-3-3zM15 9l3 3-3 3-3-3z" />
                  <path d="M10.5 10.5l3 3M4 14a6 6 0 006 6M4 10a10 10 0 0010 10" />
                </svg>
                Satellite internet connection
              </span>
            </div>
          </section>
        </div>
      </div>

      <main className="flex-1 py-6 pb-4">
        <div className="w-full max-w-[880px] mx-auto px-4">
          <div className="flex justify-between items-baseline mb-3">
            <h2 className="text-base font-bold">Choose a bundle</h2>
            <span className="text-[var(--mute)] text-xs">Prices in UGX</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {DATA_PACKAGES.map((p) => (
              <article
                key={p.id}
                className={`relative bg-white border border-[var(--line)] rounded-[var(--r)] p-4 flex flex-col transition hover:border-[var(--violet)] hover:shadow-[0_6px_18px_#12163A12] ${
                  p.b ? 'border-[var(--violet)]' : ''
                }`}
                style={{ ['--c' as string]: p.c }}
              >
                {p.b && (
                  <span className="absolute top-3 right-3 bg-[var(--violet)] text-white font-semibold text-[11px] leading-none px-2 py-1 rounded-full">
                    {p.b}
                  </span>
                )}
                <div className="text-2xl font-bold leading-tight text-[#0A4030]">
                  {p.t ? (
                    p.t
                  ) : (
                    <>
                      {p.n}
                      <small className="text-sm font-semibold ml-0.5">{p.u}</small>
                    </>
                  )}
                </div>
                <div className="flex items-center gap-1.5 text-[var(--mute)] text-[13px] mt-0.5 mb-3">
                  <i
                    className="w-1.5 h-1.5 rounded-full inline-block"
                    style={{ background: p.c }}
                  />
                  {p.d}
                </div>
                <div className="flex items-center justify-between gap-2 mt-auto">
                  <span className="font-bold text-sm bg-[var(--mint)] text-[#073B28] px-2.5 py-1.5 rounded-[10px]">
                    {formatUGX(p.p)}
                  </span>
                  <button
                    type="button"
                    onClick={() => openPay(p)}
                    className="min-h-9 px-4 rounded-[10px] border-0 bg-gradient-to-b from-[#0F6B4B] to-[#0A4D36] text-white font-semibold text-[13px] hover:brightness-110 active:scale-95 transition"
                    aria-label={`Buy ${packageLabel(p)} for ${p.d}`}
                  >
                    Buy
                  </button>
                </div>
              </article>
            ))}
          </div>

          <div className="flex justify-between items-baseline mt-6 mb-3">
            <h2 className="text-base font-bold">How it works</h2>
          </div>
          <div className="grid gap-2 sm:grid-cols-3">
            {[
              { n: '1', t: 'Choose a bundle', d: 'Pick the plan that fits you.' },
              { n: '2', t: 'Enter your number', d: 'MTN or Airtel.' },
              { n: '3', t: 'Complete the purchase', d: 'Data activates right after.' },
            ].map((s) => (
              <div
                key={s.n}
                className="flex gap-3 items-center bg-white border border-[var(--line)] rounded-[var(--r)] px-4 py-3"
              >
                <b className="flex-none w-6 h-6 rounded-full bg-[var(--ink)] text-white grid place-items-center text-xs font-semibold">
                  {s.n}
                </b>
                <div>
                  <strong className="block font-semibold text-[13px]">{s.t}</strong>
                  <span className="text-[var(--mute)] text-[13px]">{s.d}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>

      <CheckoutSheet
        pkg={selected}
        isOpen={sheetOpen}
        onClose={() => setSheetOpen(false)}
        onSuccess={handleSuccess}
      />
    </div>
  );
}
