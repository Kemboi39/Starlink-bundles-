export interface DataPackage {
  id: string;
  n: string;
  u: string;
  t?: string;
  d: string;
  p: number;
  c: string;
  b?: string;
}

export interface Purchase {
  id: string;
  reference: string;
  phone: string;
  network: 'MTN' | 'Airtel' | 'Other';
  packageId: string;
  packageLabel: string;
  duration: string;
  amount: number;
  status: 'activated' | 'pending' | 'failed';
  createdAt: string;
  txId: string;
}
