import { DataPackage } from '../types';

export const DATA_PACKAGES: DataPackage[] = [
  { id: '1', n: '7', u: 'GB', d: '24 Hours', p: 2000, c: '#14A85A' },
  { id: '2', n: '12', u: 'GB', d: '7 Days', p: 2600, c: '#14A85A' },
  { id: '3', n: '22', u: 'GB', d: '14 Days', p: 3200, c: '#14A85A', b: 'Popular' },
  { id: '4', n: '35', u: 'GB', d: '21 Days', p: 3800, c: '#14A85A', b: 'Best value' },
  { id: '5', n: '50', u: 'GB', d: '30 Days', p: 4600, c: '#14A85A' },
  { id: '6', n: '∞', u: '', t: 'Unlimited', d: '3 Months', p: 10000, c: '#14A85A', b: 'Unlimited' },
];

export function packageLabel(p: DataPackage): string {
  return p.t || `${p.n}${p.u}`;
}

export function formatUGX(amount: number): string {
  return `UGX ${Math.round(amount).toLocaleString()}`;
}

export function detectUgandaNetwork(phone: string): 'MTN' | 'Airtel' | 'Other' {
  const clean = phone.replace(/[^0-9]/g, '');
  let prefix = '';
  if (clean.startsWith('256')) {
    prefix = clean.slice(3, 5);
  } else if (clean.startsWith('0')) {
    prefix = clean.slice(1, 3);
  } else if (clean.startsWith('7')) {
    prefix = clean.slice(0, 2);
  }

  if (['77', '78', '76', '39'].includes(prefix)) return 'MTN';
  if (['70', '75', '74'].includes(prefix)) return 'Airtel';
  return 'Other';
}

export function formatUgandaPhoneNumber(phone: string): string | null {
  let formatted = phone.replace(/\s+/g, '');
  if (formatted.startsWith('+')) formatted = formatted.substring(1);
  if (formatted.startsWith('0')) formatted = '256' + formatted.substring(1);
  else if (formatted.startsWith('7')) formatted = '256' + formatted;
  else if (!formatted.startsWith('256')) return null;
  if (formatted.length !== 12 || !formatted.startsWith('256')) return null;
  return formatted;
}

export function generateRandomRef(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let result = 'STL-';
  for (let i = 0; i < 7; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return result;
}
