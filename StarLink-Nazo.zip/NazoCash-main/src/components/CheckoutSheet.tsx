import React, { useState, useEffect } from 'react';
import { DataPackage, Purchase } from '../types';
import {
  packageLabel,
  formatUGX,
  formatUgandaPhoneNumber,
  detectUgandaNetwork,
  generateRandomRef,
} from '../data/packages';

interface CheckoutSheetProps {
  pkg: DataPackage | null;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (purchase: Purchase) => void;
}

type Step = 'phone' | 'wait' | 'verifying' | 'done' | 'failed';

export const CheckoutSheet: React.FC<CheckoutSheetProps> = ({
  pkg,
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [step, setStep] = useState<Step>('phone');
  const [phone, setPhone] = useState('');
  const [error, setError] = useState('');
  const [closable, setClosable] = useState(true);
  const [countdown, setCountdown] = useState(45);
  const [refCode, setRefCode] = useState('');
  const [failureReason, setFailureReason] = useState('');

  useEffect(() => {
    if (isOpen && pkg) {
      setStep('phone');
      setPhone('');
      setError('');
      setClosable(true);
      setCountdown(45);
      setRefCode('');
      setFailureReason('');
    }
  }, [isOpen, pkg?.id]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && closable) onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [closable, onClose]);

  useEffect(() => {
    if (step !== 'verifying' || countdown <= 0) return;
    const t = setInterval(() => {
      setCountdown((c) => {
        if (c <= 1) {
          clearInterval(t);
          setFailureReason(
            'The request timed out. No Mobile Money PIN was entered before the session expired.'
          );
          setStep('failed');
          setClosable(true);
          return 0;
        }
        return c - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [step, countdown]);

  if (!isOpen || !pkg) return null;

  const label = packageLabel(pkg);
  const bigLabel = pkg.t || (
    <>
      {pkg.n}
      <small className="text-sm font-semibold ml-0.5">{pkg.u}</small>
    </>
  );

  const startServerPolling = (txId: string | number, ref: string) => {
    let attempts = 0;
    const maxAttempts = 18;
    const interval = setInterval(async () => {
      attempts++;
      if (attempts > maxAttempts) {
        clearInterval(interval);
        return;
      }
      try {
        const resp = await fetch(`/api/stk-push/status/${txId}`);
        const result = await resp.json();
        if (result.success) {
          const status = result.data?.status;
          const resultCode = result.data?.result_code;
          if (status === 'completed' || resultCode === 0) {
            clearInterval(interval);
            finishSuccess(ref, result.data?.mpesa_receipt_number);
          } else if (
            status === 'failed' ||
            resultCode === 1032 ||
            resultCode === 1037
          ) {
            clearInterval(interval);
            setFailureReason(
              result.data?.result_desc ||
                'Payment was cancelled or rejected on the phone handset.'
            );
            setStep('failed');
            setClosable(true);
          }
        }
      } catch {
        // keep polling
      }
    }, 2500);
  };

  const finishSuccess = (ref: string, receipt?: string) => {
    const network = detectUgandaNetwork(phone);
    const purchase: Purchase = {
      id: `pur-${Date.now()}`,
      reference: ref,
      phone: phone.trim(),
      network,
      packageId: pkg.id,
      packageLabel: label,
      duration: pkg.d,
      amount: pkg.p,
      status: 'activated',
      createdAt: new Date().toISOString(),
      txId: receipt || `UGX-${Math.floor(10000000 + Math.random() * 90000000)}`,
    };
    setRefCode(ref);
    onSuccess(purchase);
    setStep('done');
    setClosable(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    const formatted = formatUgandaPhoneNumber(phone);
    if (!formatted) {
      setError('Enter a valid Uganda number, like 0772 123 456.');
      return;
    }

    setClosable(false);
    setStep('wait');

    const tempRef = generateRandomRef();

    try {
      const res = await fetch('/api/stk-push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          phone: formatted,
          amount: pkg.p,
          reference: tempRef,
          description: `StarLink ${label} data bundle`,
        }),
      });

      const data = await res.json();

      if (data.success && data.data) {
        const ref = data.data.reference || tempRef;
        setRefCode(ref);
        setCountdown(45);
        setStep('verifying');
        startServerPolling(
          data.data.reference || data.data.transaction_id,
          ref
        );
      } else {
        setFailureReason(
          data.message || 'Failed to dispatch payment prompt to your phone.'
        );
        setStep('failed');
        setClosable(true);
      }
    } catch {
      setFailureReason(
        'Unable to connect to the payment server. Please check your network and try again.'
      );
      setStep('failed');
      setClosable(true);
    }
  };

  const handleClose = () => {
    if (!closable) return;
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center"
      role="dialog"
      aria-modal="true"
    >
      <div
        className="absolute inset-0 bg-[#0A403099] backdrop-blur-[3px] animate-fade"
        onClick={handleClose}
      />
      <div className="relative w-full max-w-[420px] bg-white rounded-t-[20px] sm:rounded-[20px] p-6 pb-[calc(1.5rem+env(safe-area-inset-bottom))] max-h-[92dvh] overflow-auto animate-up shadow-2xl">
        {step === 'phone' && (
          <>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-base font-bold text-[var(--text)]">
                Complete purchase
              </h3>
              <button
                type="button"
                onClick={handleClose}
                className="w-8 h-8 rounded-full bg-[var(--bg)] grid place-items-center"
                aria-label="Close"
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6">
                  <path d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="bg-[var(--bg)] rounded-[var(--r)] px-4 py-3 flex justify-between items-center mb-4">
              <div>
                <div className="text-2xl font-bold text-[#0A4030] leading-tight">
                  {bigLabel}
                </div>
                <div className="flex items-center gap-1.5 text-[var(--mute)] text-[13px] mt-0.5">
                  <i className="w-1.5 h-1.5 rounded-full bg-[var(--violet)] inline-block" />
                  {pkg.d}
                </div>
              </div>
              <div className="font-bold text-base bg-[var(--mint)] text-[#073B28] px-2.5 py-1.5 rounded-[10px]">
                {formatUGX(pkg.p)}
              </div>
            </div>

            <form onSubmit={handleSubmit} noValidate>
              <label htmlFor="ph" className="block font-semibold text-[13px] mb-1.5">
                Phone number
              </label>
              <input
                id="ph"
                type="tel"
                inputMode="tel"
                autoComplete="tel"
                placeholder="07XX XXX XXX"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full h-12 px-4 border-[1.5px] border-[var(--line)] rounded-xl text-base font-medium focus:outline-none focus:border-[var(--violet)] focus:shadow-[0_0_0_3px_#14A85A22]"
                required
                autoFocus
              />
              <div className="flex items-center gap-2 mt-3 text-[var(--mute)] text-xs">
                <span className="font-semibold text-xs leading-none px-2.5 py-2 rounded-full bg-[#FFCC00] text-[#111]">
                  MTN
                </span>
                <span className="font-semibold text-xs leading-none px-2.5 py-2 rounded-full bg-[#E8202A] text-white">
                  Airtel
                </span>
                <em className="not-italic ml-auto">Purchase is completed on this number</em>
              </div>
              {error && (
                <div className="mt-3 bg-[#FFF1F2] text-[#B4233A] rounded-[10px] px-3 py-2 text-[13px]" role="alert">
                  {error}
                </div>
              )}
              <button
                type="submit"
                className="relative overflow-hidden mt-4 w-full h-[50px] border-0 rounded-[14px] bg-gradient-to-br from-[#19C45A] via-[#0F8F4B] to-[#0A6B3A] text-white font-bold text-[15px] shadow-[0_8px_22px_#14A85A55,inset_0_1px_0_#ffffff40] hover:brightness-105 active:scale-[0.98] transition"
              >
                Pay {formatUGX(pkg.p)}
              </button>
              <p className="text-center text-[var(--mute)] text-xs mt-3">
                You will receive an MTN / Airtel Money prompt on your phone
              </p>
            </form>
          </>
        )}

        {(step === 'wait' || step === 'verifying') && (
          <div className="text-center py-4">
            <div className="spinner mx-auto mb-4" />
            <h3 className="text-lg font-bold">
              {step === 'wait' ? 'Sending payment prompt…' : 'Complete the purchase'}
            </h3>
            <p className="text-[var(--mute)] mt-2">
              {step === 'wait' ? (
                'Please wait a moment'
              ) : (
                <>
                  Finish the payment on
                  <br />
                  <strong className="text-[var(--text)]">{phone}</strong>
                  <br />
                  <span className="text-xs mt-2 inline-block">
                    Waiting for confirmation · {countdown}s
                  </span>
                </>
              )}
            </p>
          </div>
        )}

        {step === 'done' && (
          <div className="text-center pt-2">
            <div className="w-14 h-14 rounded-full bg-[var(--mint)] grid place-items-center mx-auto mb-3 animate-pop">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#14A85A" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round">
                <path d="M5 12.5l4.5 4.5L19 7.5" />
              </svg>
            </div>
            <h3 className="text-lg font-bold">Bundle activated</h3>
            <p className="text-[var(--mute)] mt-2">
              {label} is now active on {phone}
            </p>
            <div className="bg-[var(--bg)] rounded-[var(--r)] px-4 py-1 my-4 text-left text-[13px]">
              <div className="flex justify-between py-2 border-b border-[var(--line)]">
                <span className="text-[var(--mute)]">Reference</span>
                <b className="font-mono">{refCode}</b>
              </div>
              <div className="flex justify-between py-2 border-b border-[var(--line)]">
                <span className="text-[var(--mute)]">Data</span>
                <b>{label}</b>
              </div>
              <div className="flex justify-between py-2 border-b border-[var(--line)]">
                <span className="text-[var(--mute)]">Valid for</span>
                <b>{pkg.d}</b>
              </div>
              <div className="flex justify-between py-2">
                <span className="text-[var(--mute)]">Paid</span>
                <b>{formatUGX(pkg.p)}</b>
              </div>
            </div>
            <button
              type="button"
              onClick={handleClose}
              className="w-full h-[50px] rounded-[14px] bg-gradient-to-br from-[#19C45A] via-[#0F8F4B] to-[#0A6B3A] text-white font-bold text-[15px] shadow-[0_8px_22px_#14A85A55]"
            >
              Done
            </button>
          </div>
        )}

        {step === 'failed' && (
          <div className="text-center pt-2">
            <div className="w-14 h-14 rounded-full bg-[#FFF1F2] grid place-items-center mx-auto mb-3">
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#B4233A" strokeWidth="2.6" strokeLinecap="round">
                <path d="M6 18L18 6M6 6l12 12" />
              </svg>
            </div>
            <h3 className="text-lg font-bold text-[#B4233A]">Payment failed</h3>
            <p className="text-[var(--mute)] mt-2 text-sm">{failureReason}</p>
            <button
              type="button"
              onClick={() => {
                setStep('phone');
                setError('');
                setFailureReason('');
                setClosable(true);
              }}
              className="mt-4 w-full h-[50px] rounded-[14px] bg-gradient-to-br from-[#19C45A] via-[#0F8F4B] to-[#0A6B3A] text-white font-bold text-[15px]"
            >
              Try again
            </button>
            <button
              type="button"
              onClick={handleClose}
              className="mt-2 w-full h-10 text-[var(--mute)] text-sm"
            >
              Cancel
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
